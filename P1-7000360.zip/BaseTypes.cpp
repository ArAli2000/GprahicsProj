#include "BaseTypes.h"

Vector::Vector(double x, double y)
{
    this->x = x;
    this->y = y;
}
