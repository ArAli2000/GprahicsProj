#ifndef DRAW_H
#define DRAW_H
#include <glut.h>
#include <string.h>


void drawCircle(double x, double y, float r);

void drawPointLocation(double x, double y);
void print(int x, int y, char* string);


#endif