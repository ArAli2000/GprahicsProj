#ifndef Vector_H
#define Vector_H

class Vector
{
public:
    double x;

public:
    double y;

public:
    Vector(double x, double y);
};

#endif
